import os
for i in range(8, 0, -1):
	for j in range(8, 0, -1):
		for k in range (8, 0, -1):
			os.system(f"curl http://as-stats.loveliv.es/detail.php?lesson={i}{j}{k} >{i}{j}{k}.html")